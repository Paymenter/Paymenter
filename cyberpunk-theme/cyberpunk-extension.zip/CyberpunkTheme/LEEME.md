# Tema Cyberpunk para Paymenter — Sky Ultra Plus

Paquetes disponibles:

| Paquete | Qué instala | Dónde |
|---|---|---|
| `cyberpunk-tema.zip` | **El tema** (obligatorio) | `themes/cyberpunk` + `public/cyberpunk` |
| `cyberpunk-extension.zip` | **La extensión** (opcional) | `extensions/Others/CyberpunkTheme` |
| `cyberpunk-todo-en-uno.zip` | **Extensión + tema dentro**: instala las dos cosas de una vez | todo lo anterior |

El **tema funciona solo**. La **extensión** añade el panel de personalización,
la comunidad, las reseñas en los planes, los avatares y el contador de visitas.

## ¿La extensión puede instalar el tema por mí?

**Sí, pero sólo el paquete `cyberpunk-todo-en-uno.zip`**, que lleva el tema dentro.
`cyberpunk-extension.zip` es la extensión pelada y **no** trae el tema.

Con el todo-en-uno, al instalar la extensión se copia el tema a `themes/cyberpunk`,
los assets a `public/cyberpunk` y se activa el tema automáticamente.

Requisito: el usuario del servidor web tiene que poder escribir en `themes/` y en
`public/`. Compruébalo así:

```bash
cd /var/www/paymenter
sudo -u www-data test -w themes  && echo "themes: OK" || echo "themes: SIN PERMISO"
sudo -u www-data test -w public  && echo "public: OK" || echo "public: SIN PERMISO"
```

Si sale «SIN PERMISO», dale permiso sólo a esas dos carpetas:

```bash
chown www-data:www-data themes public
chmod 775 themes public
```

O simplemente instala el tema por terminal con `cyberpunk-tema.zip` (más abajo);
el resultado es idéntico.

Si la extensión no pudo copiar el tema, te lo dirá en
**Admin → Extensions → Cyberpunk Theme**: verás el aviso «El tema Cyberpunk todavía
no está activo» o «Faltan los assets compilados», y el botón **Reinstalar archivos**
vuelve a intentarlo.

---

## Por qué el tema no se sube desde el panel

Paymenter **no tiene subidor de temas**. Verificado en el código:

- `app/Admin/Pages/Extension.php` → `UploadExtensionService` es el único subidor de
  ZIP del panel y sólo acepta **extensiones**; las mueve a `extensions/`, nunca a
  `themes/`.
- Los temas se leen del disco: `app/Classes/Settings.php` los lista con
  `glob(base_path('themes/*'))` y se eligen en **Admin → Settings → Theme**.

Por eso los temas se instalan **copiando archivos**, como dice la documentación
oficial. Eso es justo lo que hace este paquete.

---

# 1) Instalar el TEMA

## Automático

```bash
cd /tmp
unzip cyberpunk-tema.zip
cd cyberpunk-tema
bash instalar.sh /var/www/paymenter        # ← pon TU ruta de Paymenter
```

El script copia el tema y los assets, ajusta permisos, activa el tema y limpia
las cachés. **No necesita Node ni npm.**

## Manual

```bash
PAYMENTER=/var/www/paymenter               # ← pon TU ruta

cd /tmp
unzip cyberpunk-tema.zip

# el tema
mkdir -p "$PAYMENTER/themes/cyberpunk"
cp -r cyberpunk-tema/cyberpunk/.  "$PAYMENTER/themes/cyberpunk/"

# los estilos y scripts ya compilados
mkdir -p "$PAYMENTER/public/cyberpunk"
cp -r cyberpunk-tema/public/.     "$PAYMENTER/public/cyberpunk/"

# permisos (cambia www-data por tu usuario web si es otro)
chown -R www-data:www-data "$PAYMENTER/themes/cyberpunk" "$PAYMENTER/public/cyberpunk"
find "$PAYMENTER/themes/cyberpunk" "$PAYMENTER/public/cyberpunk" -type d -exec chmod 755 {} \;
find "$PAYMENTER/themes/cyberpunk" "$PAYMENTER/public/cyberpunk" -type f -exec chmod 644 {} \;

# limpiar cachés
cd "$PAYMENTER"
php artisan optimize:clear
```

Después: **Admin → Settings → Theme** → elige **cyberpunk** → Guardar.

---

# 2) Instalar la EXTENSIÓN (opcional)

## Automático

```bash
cd /tmp
unzip cyberpunk-extension.zip
cd CyberpunkTheme
bash install.sh /var/www/paymenter         # ← pon TU ruta
```

Copia la extensión, la registra, ejecuta las migraciones, la deja activada y
limpia las cachés.

## Manual

```bash
PAYMENTER=/var/www/paymenter               # ← pon TU ruta

cd /tmp
unzip cyberpunk-extension.zip

mkdir -p "$PAYMENTER/extensions/Others/CyberpunkTheme"
cp -r CyberpunkTheme/.  "$PAYMENTER/extensions/Others/CyberpunkTheme/"

chown -R www-data:www-data "$PAYMENTER/extensions/Others/CyberpunkTheme"
find "$PAYMENTER/extensions/Others/CyberpunkTheme" -type d -exec chmod 755 {} \;
find "$PAYMENTER/extensions/Others/CyberpunkTheme" -type f -exec chmod 644 {} \;

cd "$PAYMENTER"
php artisan optimize:clear
```

Después, en el panel: **Admin → Extensions → Available Extensions →
pestaña "Ready to Install"** → busca *Cyberpunk Theme* → **Install** →
activa **Enabled** y guarda.

> La extensión **sí** se puede subir por **Admin → Extensions → Upload Extension**
> con el ZIP `cyberpunk-extension.zip`, porque es una extensión de verdad.

---

# 3) Dónde se configura todo

**Admin → Extensions → Cyberpunk Theme**

| Pestaña | Qué controla |
|---|---|
| General | Qué bloques se ven en el inicio, opciones de tienda, textos |
| Apariencia | 8 paletas de colores, colores manuales, efectos neón/scanlines/glitch, tipografía, imagen de fondo |
| Banner | Diapositivas (imagen, título, texto, botón) y frases de marketing en movimiento |
| Marketing | Tarjetas de servicios, ventajas y accesos rápidos |
| Páginas | Páginas nuevas con tu HTML, con enlace en la barra de navegación |
| Comunidad | Nombre, URL, descripción, límite de archivos, avatares |
| Redes sociales | Facebook, Discord, Instagram, canal y grupo de WhatsApp, Telegram, YouTube, TikTok, X, GitHub |

Botones de arriba: **Guardar cambios**, **Activar tema**, **Reinstalar archivos**,
**Reiniciar visitas** y **Restablecer todo** (vuelve a la configuración de fábrica).

Moderación: **Admin → Extensions → Comunidad · Publicaciones** y
**Comunidad · Comentarios**.

Sin la extensión, los ajustes básicos del tema (colores, textos, efectos, redes)
están en **Admin → Settings → Theme**.

---

# 4) Comprobar que funciona

```bash
cd /var/www/paymenter

# el tema está en su sitio
ls themes/cyberpunk/theme.php
ls public/cyberpunk/manifest.json

# el tema está activo
php artisan tinker --execute 'echo config("settings.theme");'   # debe imprimir: cyberpunk
```

Si la web sale sin estilos, es que falta `public/cyberpunk/` — vuelve a copiarlo
o compílalo con `npm run build cyberpunk`.

---

# 5) Problemas frecuentes

**La web sale en blanco o sin estilos**
```bash
cd /var/www/paymenter
php artisan optimize:clear
php artisan view:clear
ls public/cyberpunk/manifest.json     # tiene que existir
```

**Error 500 después de instalar**
```bash
tail -50 storage/logs/laravel.log
```

**No aparece "cyberpunk" en Settings → Theme**
La carpeta `themes/cyberpunk` no existe o el servidor web no puede leerla:
```bash
ls -la themes/
chown -R www-data:www-data themes/cyberpunk
```

**"Error durante la subida" al subir la extensión por el panel**
Es un problema de PHP en tu servidor, no del ZIP: falla la validación `uploaded`
de Laravel porque PHP no puede escribir su archivo temporal.
```bash
php -i | grep -E "upload_tmp_dir|open_basedir|file_uploads|upload_max_filesize|post_max_size"
mkdir -p storage/app/livewire-tmp storage/app/extensions/uploaded
chown -R www-data:www-data storage bootstrap/cache
chmod -R 775 storage bootstrap/cache
tail -50 storage/logs/laravel.log
```
En Nginx añade dentro del bloque `server`: `client_max_body_size 20M;`
De todas formas, con `install.sh` no necesitas el subidor.

---

# 6) Recompilar los estilos (no hace falta)

Los assets vienen compilados. Si cambias las vistas del tema:

```bash
cd /var/www/paymenter
npm install
npm run build cyberpunk
```

---

# 7) Desinstalar

```bash
cd /var/www/paymenter

# 1. volver al tema por defecto (o hazlo en Admin → Settings → Theme)
php artisan tinker --execute '\App\Models\Setting::where("key","theme")->update(["value"=>"default"]);'

# 2. borrar el tema
rm -rf themes/cyberpunk public/cyberpunk

# 3. la extensión: desinstálala primero desde Admin → Extensions
#    (así borra sus tablas), y luego:
rm -rf extensions/Others/CyberpunkTheme

php artisan optimize:clear
```
